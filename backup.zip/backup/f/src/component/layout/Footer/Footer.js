import React from 'react'
import playStore from "../../../images/playStore.png"
import appStore from "../../../images/appStore.png"
import './Footer.css';
export default function Footer() {
    return (
        <footer id="footer">
            <div className="leftFooter">
                <h4>DOWNLOAD OUR APP</h4>
                <p>Download App for the Android and IOs Mobile Phone</p>
                <img src={playStore} alt="playstore" />
                <img src={appStore} alt="appstore" />
            </div>
            <div className="midFooter">
                <h1>Ecommerce</h1>
                <p>High Quality is our first </p>
                <p>Copyrights 2022 &copy; Amit Kumar </p>
            </div>
            <div className="rightFooter">
                <h4>Follow Us</h4>
                <a href="https:://abc.com">Instagram</a>
                <a href="https:://abc.com">Fecebook</a>
                <a href="https:://abc.com">Tweeter</a>
            </div>

        </footer>
    )
}
