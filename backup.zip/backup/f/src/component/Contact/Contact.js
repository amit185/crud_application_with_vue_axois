import React from 'react'

export default function Contact() {
    return (
        <div>
            <h1>this is the Contact page</h1>
            
        </div>
    )
}
