import React from 'react'
import { Link } from 'react-router-dom'
import ReactStars from "react-rating-stars-component";
import './Product.css';

export default function Product(product) {
    // const { name, price, id,images,ratings,noOfReviews } = product.product
    const { name, price, _id, images, ratings,noOfReviews } = product.product
    console.log()
    const options = {
        edit:false,
        color:"rgba(20,20,20,0.1)",
        activeColor :"tomato",
        size:window.innerWidth < 600 ? 20 :25,
        value:ratings,
        isHalf:true
    }
    // console.log("Amiut",);
    return (
        <>
           <Link className="productCard" to={`product/${_id}`}>
               <img src={images[0].url}  />
               <p>{name}</p>
               <div>
                   <ReactStars {...options} /><span>({noOfReviews} Reviews)</span>
               </div>
               <span>{`₹${price}`}</span>

           </Link> 
           
        </>
    ) 
}
