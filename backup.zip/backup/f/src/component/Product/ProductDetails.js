import React,{useEffect} from 'react'
import './ProductDetaail.css';
import Carousel from 'react-material-ui-carousel';
import { useSelector, useDispatch} from 'react-redux';
import { getProductDetail } from '../../actions/productActions';
import Loader from '../layout/Loader/Loader';
import { useParams } from "react-router-dom";
import ReactStars from "react-rating-stars-component";

const  ProductDetails = ()=> {
    
    const {id}  = useParams();

    const dispatch = useDispatch()

    // const product  = useSelector(state=>state.productDetails);
    const { loading,product } = useSelector(state=>state.productDetails);
    useEffect(() => {
        dispatch(getProductDetail(id))
    }, [dispatch,id])
    const options = {
        edit:false,
        color:"rgba(20,20,20,0.1)",
        activeColor :"tomato",
        size:window.innerWidth < 600 ? 20 :25,
        value:product.ratings,
        isHalf:true
    }
    return (
        <>
            {
                loading?<Loader /> :(
                    <>
                    <div className="ProductDetailsDes">
                        <div>
                            <div>

                            <Carousel>
                                {
                                    product.images && 
                                        product.images.map((item, i)=>(
                                            <img
                                                className="CarousalImage"
                                                key={item.url}
                                                src={item.url}
                                                alt={ `${i} Slide`}
                                            />
                                        ))
                                }
                               
                            </Carousel>
                            
                            </div>
                        </div>
                        <div>
                            <div className="detailsBlock-1">
                                <h2>{product.name}</h2>
                                <p>Product # {product._id}</p>
                            </div>
                            <div className="detailsBlock-2">
                                <ReactStars {...options} />
                                <span>({product.noOfReviews} Reviews)</span>
                                
                            </div>
                            <div className="detailsBlock-3">
                                <h1>{`${product.price}`}</h1>
                                <div className="detailsBlock-3-1">
                                    <div className="detailsBlock-3-1-1">
                                        <button>-</button>
                                        <input type="number" value='1'></input>
                                        <button>+</button>
                                    </div>
                                    <button>Add To Cart</button>
                                </div> 
                                <p>
                                    Status:
                                    <b className={product.stock <1 ? "redColor" : "greenColor"}>
                                        {product.stock < 1 ?"OutOfStock":"InStock"}
                                    </b>

                                </p>                           
                                
                            </div>
                            <div className="detailsBlock-4">
                                Description: <p>{product.description}</p>
                            </div>
                            <button className="submitReview">Submit Review</button>
                        </div>
                    </div>
                    
                
                </>
                )   
            }
        </>
       
    )
}

export default ProductDetails
