import Header from './component/layout/Header/Header';
import Footer from './component/layout/Footer/Footer';
import Home from './component/Home/Home';
import Contact from './component/Contact/Contact';
import ProductDetails from './component/Product/ProductDetails.js'
import './App.css'
import { BrowserRouter,Routes,Route } from "react-router-dom";

import React from "react";
import WebFont from 'webfontloader';
import Loader from './component/layout/Loader/Loader';

function App() {
  React.useEffect(()=>{
    WebFont.load({
      google:{
        families:["Roboto","Droid sans","Chilanka"]
      }
    })
  },[])
  return (
      <BrowserRouter>
        <Header />
        <Routes>
            <Route exact path="/" element={<Home />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/product/:id" element={<ProductDetails />} />
            <Route path="/test-loader" element={<Loader />} />
        </Routes>
        <Footer />
      </BrowserRouter>
  );
}

export default App;
