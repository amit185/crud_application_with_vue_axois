import {
    ALL_PRODUCT_REQUEST,
    ALL_PRODUCT_SUCCESS,
    ALL_PRODUCT_FAIL,
    CLEAR_ERROR
} from "../constants/producContants";

const initialState = {
    loading:true,
    proudcts:[],
    productCount: 0
}

export const productReducer = (state = initialState , action)=>{
    // console.log("TestStart",action,"TestEnd");
    switch (action.type) {
        case ALL_PRODUCT_REQUEST:
            return {
                loading:true,
                product:[]
            };
        case ALL_PRODUCT_SUCCESS:
            return {
                
                loading:false,
                proudcts:action.payload.products,
                productCount:action.payload.productCount,
            };
        case ALL_PRODUCT_FAIL:
            return {
               
                loading:false,
                error:action.payload
            };
        case CLEAR_ERROR:
            return {
                ...state,
                error:null
            }
           
    
        default:
            return state;
    }
}