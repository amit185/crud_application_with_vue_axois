const express = require('express');
const { 
    newOrder,
    getSingleOrder,
    getMyOrder,
    getAllOrder,
    updateOrderStatus,
    deleteOrder
} = require('../controllers/orderController');
const router = express.Router();
const { isAuthenticatedUser,authorizedRole } = require('../middleware/auth');


router.route('/order/new').post(isAuthenticatedUser,newOrder);
router.route('/order/:id').get(isAuthenticatedUser,getSingleOrder);
router.route('/my-orders').get(isAuthenticatedUser,getMyOrder);

router.route('/admin/orders').get(isAuthenticatedUser,authorizedRole("admin"),getAllOrder);
router
    .route('/admin/order/:id')
    .put(isAuthenticatedUser,authorizedRole("admin"),updateOrderStatus)
    .delete(isAuthenticatedUser,authorizedRole("admin"),deleteOrder);


module.exports  = router;