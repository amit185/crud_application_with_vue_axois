const express = require('express');
const { 
    createUser,
    getAllUsers,
    getUserDetails,
    updateUser,
    deleteUser,
    userlogin,
    logout,
    forgotPassword,
    userProfileDetails,
    updatePassword,
    updateProfile,
    userRegistration,
    updateProfileByRole
} = require('../controllers/userController');
const { isAuthenticatedUser,authorizedRole } = require('../middleware/auth');


const router = express.Router();

// Login Management
router.route('/register').post(userRegistration);
router.route('/login').post(userlogin);
router.route('/logout').get(logout);
router.route('/forgot/password').post(forgotPassword);

// logged  In User Details
router.route('/profile-details').get(isAuthenticatedUser,userProfileDetails);
router.route('/update/password').post(isAuthenticatedUser,updatePassword);
router.route('/update/profile').post(isAuthenticatedUser,updateProfile);

// User Management in Admin Module
router.route('/admin/users').get(isAuthenticatedUser,authorizedRole("admin"),getAllUsers);
router.route('/admin/user/create').post(isAuthenticatedUser,authorizedRole("admin"),createUser);
router.route('/admin/user/:id').put(isAuthenticatedUser,authorizedRole("admin"),updateUser);
router.route('/admin/user/:id').delete(isAuthenticatedUser,authorizedRole("admin"),deleteUser);
router.route('/admin/user/:id').get(isAuthenticatedUser,authorizedRole("admin"),getUserDetails);
router.route('/admin/userUpdateRole/:id').put(isAuthenticatedUser,authorizedRole("admin"),updateProfileByRole);

module.exports = router; 