const express = require('express');

const { 
    getAllProduct,
    createProduct,
    updateProduct,
    getProductDetails,
    deleteProduct,
    createProductReview,
    getReviewDetails,
    deletReview
} = require('../controllers/productController');

const { isAuthenticatedUser,authorizedRole } = require('../middleware/auth');

const router = express.Router();
// console.log(express);

router.route("/products").get(getAllProduct);

router.route("/product/:id").get(getProductDetails);

router.route("/admin/product/create").post(isAuthenticatedUser,authorizedRole("admin"), createProduct);

// Review Route
router.
route("/review").
get(getReviewDetails).
put(isAuthenticatedUser, createProductReview).
delete(isAuthenticatedUser,deletReview);

router.
route("/admin/product/:id").
put(isAuthenticatedUser,authorizedRole("admin"), updateProduct).
delete(isAuthenticatedUser,authorizedRole("admin"), deleteProduct).
delete(isAuthenticatedUser,authorizedRole("admin"), createProductReview);

module.exports = router