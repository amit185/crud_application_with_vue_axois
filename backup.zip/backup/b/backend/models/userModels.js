const mongoose = require('mongoose');
const validator = require('validator'); 
const bcrypt = require('bcryptjs');
const jwt  = require('jsonwebtoken');
const crypto  = require('crypto'); 

const userSchema = mongoose.Schema({
    name:{
        type:String,
        required:[true,"The name field should be required! "],
        maxLength:[32,"The name cannot exceed 32 charecters"],
        minlength:[4,"Name cannot less then 4 Charecters"],

    },
    email:{
        type:String,
        required:[true,"The E-mail field should be required "],
        unique:true,
        validate:[validator.isEmail,"Please Enter the valid E-mail"]
    },
    password:{
        type:String,
        required:[true,'Password field should be required'],
        minLength:[6,'Password cannot less then 6 Charectors'],
        select:false
    },
    avatar:{
        public_id:{
            type:String,
            required:true
        },
        url:{
            type:String,
            required:true
        }
    },
    role:{
        type:String,
        default:'user'
    },
    resetpasswordtoken:String,
    resetpasswordexpire:Date

});

userSchema.pre("save",async function(next){
    if(!this.isModified("password")){
        next();
    }
    this.password = await bcrypt.hash(this.password,10);
});

userSchema.methods.getJWTToken  = function(){
    return jwt.sign({ id:this._id},process.env.JWT_SECRET,{
        expiresIn:process.env.JWT_EXPIRE
    });
}

userSchema.methods.comparePassword = async function(enterPassword){
    return await bcrypt.compare(enterPassword,this.password);
}

userSchema.methods.getResetPasswordToken =async function(){
    const resetToken = crypto.randomBytes(20).toString('hex');

    // Hashing and adding resetPasswordToken to userSchema
    this.resetpasswordtoken = crypto
    .createHash('sha256')
    .update(resetToken)
    .digest('hex');

    this.resetpasswordexpire = Date.now() + 15 * 60 * 1000;
    return resetToken;
}
module.exports = mongoose.model("User",userSchema);