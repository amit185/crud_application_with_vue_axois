const catchAsyncErro = require('../middleware/catchAsyncErro');
const Product = require('../models/productModels');
const Order = require('../models/orderModels');
const ApiFeatures = require('../utils/apiFeatures');
const ErrorHander = require('../utils/errorhander');

exports.newOrder = catchAsyncErro( async(req,res,next)=>{
    const {
        shippingInfo,
        orderItems,
        paymentInfo,
        itemPrice,
        taxPrice,
        shippingPrice,
        totalPrice,
    } = req.body;

    const order = await Order.create({
        shippingInfo,
        orderItems,
        paymentInfo,
        itemPrice,
        taxPrice,
        shippingPrice,
        totalPrice,
        paidAt:"12/20/2022",
        userId:req.user._id
    });
    res.status(200).json({
        success:true,
        message:"Your Order has been successfully placed!",
        order
    })
});

exports.getSingleOrder = catchAsyncErro( async(req,res,next)=>{
    // console.log(req.params.id);
    const  order = await Order.findById(req.params.id).populate(
        "userId",
        "name email"
    );

    if(!order){
        return next(new ErrorHander('Order not found with id',404));
    }

    res.status(200).json({
        success:true,
        order
    })
}); 

// My Order 
exports.getMyOrder = catchAsyncErro( async(req,res,next)=>{
    const  orders = await Order.find({userId:req.user._id}).populate(
        "userId",
        "name email"
    );

    if(!orders){
        return next(new ErrorHander('Order not found with id',404));
    }

    res.status(200).json({
        success:true,
        orders
    })
}); 

// Overall order of the user in Admin Module
exports.getAllOrder = catchAsyncErro( async(req,res,next)=>{
    const  orders = await Order.find().populate(
        "userId",
        "name email"
    );
    let total_price = 0;
    orders.forEach((price)=>{
        total_price += price.totalPrice
    })
    if(!orders){
        return next(new ErrorHander('Order not found with this id',404));
    }

    res.status(200).json({
        success:true,
        total_price,
        orders
    })
}); 

// upadate Status of order in Admin Module
exports.updateOrderStatus = catchAsyncErro( async(req,res,next)=>{
    const  order = await Order.findById(req.params.id);
    if(!order){
        return next(new ErrorHander('Your order does not exit',400));
    }
    if(order.orderStatus == "Delivered"){
        return next(new ErrorHander('Your Order has been deleverd',400));
    }
   
    order.orderItems.forEach(async (myOrder)=>{

        await updateStock(myOrder.product_id,myOrder.quantity);
        
    })

    order.orderStatus = req.body.status;
    if(req.body.status == "Delivered"){
        order.deliveryAt = Date.now();
    }
    await order.save({validateBeforeSave:false});
    res.status(200).json({
        success:true,
    })
}); 

async function updateStock(id,quantity){
     product = await Product.findById(id);
     
    product.stock -= quantity;
    await product.save({validateBeforeSave:false});
}

// delete order Admin Module
exports.deleteOrder = catchAsyncErro( async(req,res,next)=>{

    const  orders = await Order.findById(req.params.id);

    if(!orders){
        return next(new ErrorHander('Order not found with this id',404));
    }
    await orders.remove();

    res.status(200).json({
        success:true,
       
    })
}); 