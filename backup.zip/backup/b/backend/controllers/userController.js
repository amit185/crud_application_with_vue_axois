const catchAsyncErro = require('../middleware/catchAsyncErro');
const User = require('../models/userModels');
const ApiFeatures = require('../utils/apiFeatures');
const ErrorHander = require('../utils/errorhander');
const sendToken = require('../utils/jwtToken');
const sendEmail = require('../utils/sendEmail')


// Create New User
exports.userRegistration = catchAsyncErro(
    async (req,res,next)=>{
        const user = await User.create(req.body);
        if(!user){
            return next(new ErrorHander('User create Failed',404));
        }
       const token =  user.getJWTToken();
        res.status(201).json({
            succuss:true,
            token
        })
    }
)
exports.createUser = catchAsyncErro(
    async (req,res,next)=>{
        const user = await User.create(req.body);
        if(!user){
            return next(new ErrorHander('User create Failed',404));
        }
        res.status(201).json({
            succuss:true,
            message:"User has been successfully Created"
        })
    }
)


// User login functionality using the jwt token 
exports.userlogin = catchAsyncErro( 
    async (req,res,next)=>{

        const {email, password} = req.body;
        if(!email || !password){
            return next(new ErrorHander('Please Enter the E-mail & Password',400));

        }
        const user = await User.findOne({email}).select("+password");
        if(!user){
            return next(new ErrorHander('Invalid E-mail or Password',401));
        }
        const isPasswordMatched = await user.comparePassword(password);

        if(!isPasswordMatched){
            return next(new ErrorHander("Invalid E-mail or Password",401));
        }

        sendToken(user,200,res)
      
    }
);

exports.logout = catchAsyncErro(async (req,res,next)=>{
    res.cookie("token",null,{
        expires:new Date(Date.now()),
        httpOnly:true
    });
    res.status(200).json({
        success:true,
        message:"logged Out"
    })
})

exports.getAllUsers = async (req,res)=>{
    let resultPerPage = 150;
    const usersCount = await User.countDocuments();
    const apiFeatures = new ApiFeatures(User.find(),req.query).search().filter().pagination(resultPerPage);
    const user = await apiFeatures.query;
    if(!user){
        return next(new ErrorHander("User not Found",404));
    }
    res.status(201).json({
        success:true,
        user,
        usersCount
    })

}

exports.getUserDetails = async (req,res,next)=>{
    const user  = await User.findById(req.params.id);

    if(!user){
        return next(new ErrorHander('User not Fount',404));
    
    }
    res.status(200).json({
        success:true,
        user
    })
}

exports.updateUser = catchAsyncErro(
    async (req,res,next)=>{
        let user = await User.findById(req.params.id);
        if(!user){
            return next(new ErrorHander('User does not exist',404));
        }
        user  = await User.findByIdAndUpdate(req.params.id,req.body,{
            new:true,
            runValidators:true,
            useFindAndModify:false
        });
    
        res.status(200).json({
            success:true,
            user
        });
    }
)

exports.deleteUser = async (req,res,next)=>{
    const user = await User.findById(req.params.id);
    if(!user){
        return next(new ErrorHander("User does not exist",404));
    }
    await user.remove();
    res.status(200).json({
        success:true,
        message:"Record has been deleted"
    })
}

// Forget Passowrd
exports.forgotPassword =  catchAsyncErro(

    async (req,res,next)=>{
        const user = await User.findOne({email:req.body.email});
        if(!user){
            return next(new ErrorHander('User not found',404));
        }
        console.log(user);
        // Get ResetPassword Token
        const resetToken = user.getResetPasswordToken();
        // console.log(resetToken);
        await user.save({ validateBeforeSave:false});

        const resetPasswordUrl = `${req.protocol}://${req.get('host')}/api/v1/password/reset/${resetToken}`;

        const message =    `Your password reset token is :- \n\nIf you have not requested this email then, please ignore it.`;

        try{
            console.log('test')
            await sendEmail({
                email:user.email,
                subject:"E-commerce Password Recovery",
                message:resetPasswordUrl
            });
            res.status(200).json({
                success:true,
                message:`E-mail send to ${user.email} successfully`
            })
        }catch(error){
            user.resetpasswordtoken = undefined;
            user.resetpasswordexpire = undefined;
            await user.save({validateBeforeSave:false});
            return next(new ErrorHander(error.message,500));
        }
    }
);

// Get the user Profile  Details
exports.userProfileDetails = catchAsyncErro(
    async(req,res,next)=>{
        const user = await User.findById(req.user.id);
        res.status(200).json({
            success:true,
            user
        });
    }
);

// Update user Password
exports.updatePassword = catchAsyncErro(
    async(req,res,next)=>{
        const user = await User.findById(req.user.id).select('+password');
        const isPasswordMatched = await user.comparePassword(req.body.old_password);

        if(!isPasswordMatched){
            return next(new ErrorHander("Old Password is invalid",400));
        } 

        if(req.body.new_password !== req.body.confirm_password){
            return next(new ErrorHander('New password and confirm password should be same',400));
        }

        user.password = req.body.new_password;
        await user.save();

        sendToken(user,200,res);
       
    }
);

exports.updateProfile = catchAsyncErro(
    async (req,res,next)=>{

        const updateData = {
            email:req.body.email,
            name:req.body.name,

        }
        const user  =await User.findByIdAndUpdate(req.user.id,updateData,{
            new:true,
            runValidators:true,
            userFindAndModify:false
        });

        res.status(200).json({
            success:true,
            message:'user profile has been updated'
        })

    }
)
exports.updateProfileByRole = catchAsyncErro(
    async (req,res,next)=>{

        const updateData = {
            email:req.body.email,
            name:req.body.name,
            role:req.body.role,

        }
        const user  =await User.findByIdAndUpdate(req.params.id,updateData,{
            new:true,
            runValidators:true,
            userFindAndModify:false
        });

        res.status(200).json({
            success:true,
            message:'user profile has been updated'
        })

    }
)
