const nodemailer = require('nodemailer');

const sendEmail = async (options)=>{
    console.log('Test123');
    var smtpConfig = {
        host: 'smtp.gmail.com',
        port: 465,
        // secure: true, // use SSL
        service:process.env.SMTP_SERVICE,
        auth: {
            user: 'testamitnodejs@gmail.com',
            // user: 'testamitnodejs@gmail.com',
            pass: 'Sahil1996@@'
        }
    };
    var transporter = nodemailer.createTransport(smtpConfig);
    // const transporter  = nodeMailer.createTransport("SMTP",{
    //     // host: 'smtp.gmail.com',
    //     // port: 465,
    //     // secure: true,
    //     service:process.env.SMTP_SERVICE,
    //     auth:{
    //         user:process.env.SMTP_MAIL,
    //         pass : process.env.SMTP_PASSWORD
    //     }
    // });

    console.log(transporter);
    const mailOptions = {
        from :process.env.SMTP_MAIL,
        to:options.subject,
        subject:options.subject,
        text:options.message
    }
    await transporter.sendMail(mailOptions);
    
}

module.exports = sendEmail;