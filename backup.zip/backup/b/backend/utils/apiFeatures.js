class ApiFeatures{

    constructor(query,queryStr){
        this.query = query;
        this.queryStr = queryStr;
    }

    search(){
        const keyword = this.queryStr.keyword?{
            name:{
                $regex:this.queryStr.keyword,
                $options:'i'
                
            }
        }:{};
        // console.log(keyword);
        this.query = this.query.find({...keyword});
        return this;
    }
    filter(){
        const queryCopy = {...this.queryStr}; // for the copy the data without any effected the data
        const removeField  =  ["keyword","page","limit"];
        // console.log("before deleting ",queryCopy);

        removeField.forEach((key)=>delete queryCopy[key]);
        // console.log("before",queryCopy);
        // Filter for the price and rating
        let queryStr =JSON.stringify(queryCopy);
        queryStr  = queryStr.replace(/\b(gt|gte|lt|lte)\b/g,(key)=>`$${key}`);

        // console.log("after",queryStr);
        this.query = this.query.find(JSON.parse(queryStr));
        // console.log("after deleting data ",queryCopy);
        return this;
    }

    pagination(resultPerPage){
        const currentPage  = Number(this.queryStr.page) || 1;
        const skip = resultPerPage * (currentPage - 1);
        this.query = this.query.limit(resultPerPage).skip(skip);
        return this;
    }
}


module.exports  = ApiFeatures;